﻿namespace Inheritence
{
    public class BaseClass
    {
    }
}
