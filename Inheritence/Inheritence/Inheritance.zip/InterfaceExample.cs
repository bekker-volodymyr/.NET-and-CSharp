﻿namespace Inheritence
{
    public interface InterfaceExample
    {
    }
}
