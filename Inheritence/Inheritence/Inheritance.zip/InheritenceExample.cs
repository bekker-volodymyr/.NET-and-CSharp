﻿namespace Inheritence
{
    public class InheritenceExample : BaseClass, InterfaceExample
    {

    }
}
